package reply.main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import reply.dao.InputDao;
import reply.model.Input;
import reply.model.Output;
import reply.model.Antenna;
import reply.model.Building;
import reply.utility.Utility;

public class ReplyMain {
	public final static int MAX_ITER =10;
	public final static int DIMENSION =2;
	
	public static void main(String[] args) throws IOException {
		String filename = "f";
		InputDao inputDao = InputDao.getInstance();
		Input input = inputDao.parser("input\\" + filename + ".txt");
		//System.out.println(input.toString());
		
		List<Building> builds = new ArrayList<>(input.getBuildingsList());

		List<Antenna> antennas = new ArrayList<>(input.getAntennasList());
		
		//sort discendente
		antennas = antennas.stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList());
		
		//Collections.sort(antennas);
		
		int indexAntennas = 0;
		for (indexAntennas = 0; indexAntennas < input.getNumAntennas() && builds.size() > 0; indexAntennas++) {
			Building bMax = builds.remove(Utility.indexBuildMaxSpeed(builds));
			Antenna a = antennas.get(indexAntennas);
			int[] position = bMax.getPosition();
			builds = builds.stream().filter((b) -> !Utility.isOnRange(position, a.getRange(), b.getPosition())).collect(Collectors.<Building>toList());
			a.setPosition(position);
			antennas.set(indexAntennas, a);
		}		
		
		if(builds.size() > 0) {
			String ciao ="";
		}
		
		Output out = new Output();
		out.setNumAntennas(indexAntennas);
		List<Antenna> outAntenna = new ArrayList<>();
		for (int i = 0; i < indexAntennas; i++) {
			outAntenna.add(antennas.get(i));
		}
		out.setAntennaOut(outAntenna);
		
		Utility.writeFileOutput(out.toString(), filename);
	}
}
