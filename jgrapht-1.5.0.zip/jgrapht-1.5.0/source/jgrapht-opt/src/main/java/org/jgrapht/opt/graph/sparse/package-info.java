/**
 * A specialized graph implementation using a sparse matrix representations.
 */
package org.jgrapht.opt.graph.sparse;
